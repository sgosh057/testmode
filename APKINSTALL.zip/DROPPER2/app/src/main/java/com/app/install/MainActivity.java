package com.app.install;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    private static final String PACKAGE_NAME = "com.my.newproject25";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Button updateButton = findViewById(R.id.update_button);
        updateButton.setOnClickListener(v -> checkPermissionsAndInstall());
    }

    private void checkPermissionsAndInstall() {
        if (!getPackageManager().canRequestPackageInstalls()) {
            requestInstallUnknownAppsPermission();
            return;
        }
        installApk();
    }

    private void requestInstallUnknownAppsPermission() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
        startActivity(intent);
        Toast.makeText(this, "Enable permission to install apps from unknown sources.", Toast.LENGTH_LONG).show();
    }

    private void installApk() {
        try {
            InputStream inputStream = getResources().openRawResource(R.raw.update);
            File tempApkFile = new File(getCacheDir(), "update.apk");
            FileOutputStream outputStream = new FileOutputStream(tempApkFile);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, length);
            }
            outputStream.close();
            inputStream.close();
            Uri apkUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".provider",
                    tempApkFile
            );
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, 1);

        } catch (Exception e) {
            Toast.makeText(this, "Failed to install APK: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                if (isAppInstalled()) {
                    Toast.makeText(this, "APK Installed Successfully!", Toast.LENGTH_SHORT).show();
                    launchApp();
                } else {
                    Toast.makeText(this, "APK Installation Failed", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "APK Installation Failed", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private boolean isAppInstalled() {
        PackageManager packageManager = getPackageManager();
        try {
            PackageInfo packageInfo = packageManager.getPackageInfo(MainActivity.PACKAGE_NAME, PackageManager.GET_ACTIVITIES);
            return packageInfo != null;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
    private void launchApp() {
        Intent intent = getPackageManager().getLaunchIntentForPackage(PACKAGE_NAME);
        if (intent != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this, "Could not launch the app.", Toast.LENGTH_SHORT).show();
        }
    }
}
